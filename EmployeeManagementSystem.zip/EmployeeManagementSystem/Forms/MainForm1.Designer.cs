﻿namespace EmployeeManagementSystem.Forms
{
    partial class MainForm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MsMain = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ssStatus = new System.Windows.Forms.StatusStrip();
            this.lblStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.btnManageEmployees = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.pnlCardContainer = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlTotalDepts = new System.Windows.Forms.Panel();
            this.lblTotalDepartmentsCount = new System.Windows.Forms.Label();
            this.pnlActiveEmp = new System.Windows.Forms.Panel();
            this.lblActiveEmployeesCount = new System.Windows.Forms.Label();
            this.pnlTotalEmp = new System.Windows.Forms.Panel();
            this.lblTotalEmployeesCount = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.ssStatus.SuspendLayout();
            this.pnlCardContainer.SuspendLayout();
            this.pnlTotalDepts.SuspendLayout();
            this.pnlActiveEmp.SuspendLayout();
            this.pnlTotalEmp.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MsMain,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(10, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1000, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MsMain
            // 
            this.MsMain.Name = "MsMain";
            this.MsMain.Size = new System.Drawing.Size(89, 24);
            this.MsMain.Text = "Employee";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(47, 24);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // ssStatus
            // 
            this.ssStatus.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.ssStatus.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblStatus});
            this.ssStatus.Location = new System.Drawing.Point(0, 620);
            this.ssStatus.Name = "ssStatus";
            this.ssStatus.Padding = new System.Windows.Forms.Padding(1, 0, 17, 0);
            this.ssStatus.Size = new System.Drawing.Size(1000, 26);
            this.ssStatus.TabIndex = 1;
            this.ssStatus.Text = "statusStrip1";
            // 
            // lblStatus
            // 
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(50, 20);
            this.lblStatus.Text = "Ready";
            // 
            // btnManageEmployees
            // 
            this.btnManageEmployees.BackColor = System.Drawing.Color.LightCoral;
            this.btnManageEmployees.Location = new System.Drawing.Point(351, 408);
            this.btnManageEmployees.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnManageEmployees.Name = "btnManageEmployees";
            this.btnManageEmployees.Size = new System.Drawing.Size(276, 93);
            this.btnManageEmployees.TabIndex = 2;
            this.btnManageEmployees.Text = "Manage Employees";
            this.btnManageEmployees.UseVisualStyleBackColor = false;
            this.btnManageEmployees.Click += new System.EventHandler(this.btnManageEmployees_Click_1);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(840, 556);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(125, 36);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // pnlCardContainer
            // 
            this.pnlCardContainer.Controls.Add(this.label3);
            this.pnlCardContainer.Controls.Add(this.label2);
            this.pnlCardContainer.Controls.Add(this.label1);
            this.pnlCardContainer.Controls.Add(this.pnlTotalDepts);
            this.pnlCardContainer.Controls.Add(this.pnlActiveEmp);
            this.pnlCardContainer.Controls.Add(this.pnlTotalEmp);
            this.pnlCardContainer.Location = new System.Drawing.Point(173, 157);
            this.pnlCardContainer.Name = "pnlCardContainer";
            this.pnlCardContainer.Size = new System.Drawing.Size(659, 228);
            this.pnlCardContainer.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(454, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(159, 23);
            this.label3.TabIndex = 5;
            this.label3.Text = "Total Departments";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(246, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 23);
            this.label2.TabIndex = 4;
            this.label2.Text = "Active Emloyees";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 23);
            this.label1.TabIndex = 3;
            this.label1.Text = "Total Employees";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // pnlTotalDepts
            // 
            this.pnlTotalDepts.BackColor = System.Drawing.Color.White;
            this.pnlTotalDepts.Controls.Add(this.lblTotalDepartmentsCount);
            this.pnlTotalDepts.Location = new System.Drawing.Point(449, 65);
            this.pnlTotalDepts.Name = "pnlTotalDepts";
            this.pnlTotalDepts.Size = new System.Drawing.Size(164, 116);
            this.pnlTotalDepts.TabIndex = 2;
            // 
            // lblTotalDepartmentsCount
            // 
            this.lblTotalDepartmentsCount.AutoSize = true;
            this.lblTotalDepartmentsCount.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalDepartmentsCount.Location = new System.Drawing.Point(39, 35);
            this.lblTotalDepartmentsCount.Name = "lblTotalDepartmentsCount";
            this.lblTotalDepartmentsCount.Size = new System.Drawing.Size(104, 41);
            this.lblTotalDepartmentsCount.TabIndex = 0;
            this.lblTotalDepartmentsCount.Text = "label1";
            // 
            // pnlActiveEmp
            // 
            this.pnlActiveEmp.BackColor = System.Drawing.Color.White;
            this.pnlActiveEmp.Controls.Add(this.lblActiveEmployeesCount);
            this.pnlActiveEmp.Location = new System.Drawing.Point(239, 66);
            this.pnlActiveEmp.Name = "pnlActiveEmp";
            this.pnlActiveEmp.Size = new System.Drawing.Size(156, 116);
            this.pnlActiveEmp.TabIndex = 1;
            // 
            // lblActiveEmployeesCount
            // 
            this.lblActiveEmployeesCount.AutoSize = true;
            this.lblActiveEmployeesCount.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActiveEmployeesCount.Location = new System.Drawing.Point(27, 34);
            this.lblActiveEmployeesCount.Name = "lblActiveEmployeesCount";
            this.lblActiveEmployeesCount.Size = new System.Drawing.Size(104, 41);
            this.lblActiveEmployeesCount.TabIndex = 0;
            this.lblActiveEmployeesCount.Text = "label1";
            // 
            // pnlTotalEmp
            // 
            this.pnlTotalEmp.BackColor = System.Drawing.Color.White;
            this.pnlTotalEmp.Controls.Add(this.lblTotalEmployeesCount);
            this.pnlTotalEmp.Location = new System.Drawing.Point(47, 66);
            this.pnlTotalEmp.Name = "pnlTotalEmp";
            this.pnlTotalEmp.Size = new System.Drawing.Size(141, 117);
            this.pnlTotalEmp.TabIndex = 0;
            // 
            // lblTotalEmployeesCount
            // 
            this.lblTotalEmployeesCount.AutoSize = true;
            this.lblTotalEmployeesCount.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalEmployeesCount.Location = new System.Drawing.Point(13, 34);
            this.lblTotalEmployeesCount.Name = "lblTotalEmployeesCount";
            this.lblTotalEmployeesCount.Size = new System.Drawing.Size(104, 41);
            this.lblTotalEmployeesCount.TabIndex = 3;
            this.lblTotalEmployeesCount.Text = "label1";
            this.lblTotalEmployeesCount.Click += new System.EventHandler(this.label1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Maroon;
            this.label4.Location = new System.Drawing.Point(255, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(562, 45);
            this.label4.TabIndex = 6;
            this.label4.Text = "Employee Management Dashboard";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // MainForm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(1000, 646);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pnlCardContainer);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnManageEmployees);
            this.Controls.Add(this.ssStatus);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "MainForm1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ssStatus.ResumeLayout(false);
            this.ssStatus.PerformLayout();
            this.pnlCardContainer.ResumeLayout(false);
            this.pnlCardContainer.PerformLayout();
            this.pnlTotalDepts.ResumeLayout(false);
            this.pnlTotalDepts.PerformLayout();
            this.pnlActiveEmp.ResumeLayout(false);
            this.pnlActiveEmp.PerformLayout();
            this.pnlTotalEmp.ResumeLayout(false);
            this.pnlTotalEmp.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MsMain;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.StatusStrip ssStatus;
        private System.Windows.Forms.ToolStripStatusLabel lblStatus;
        private System.Windows.Forms.Button btnManageEmployees;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Panel pnlCardContainer;
        private System.Windows.Forms.Panel pnlTotalDepts;
        private System.Windows.Forms.Panel pnlActiveEmp;
        private System.Windows.Forms.Panel pnlTotalEmp;
        private System.Windows.Forms.Label lblTotalEmployeesCount;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTotalDepartmentsCount;
        private System.Windows.Forms.Label lblActiveEmployeesCount;
        private System.Windows.Forms.Label label4;
    }
}

