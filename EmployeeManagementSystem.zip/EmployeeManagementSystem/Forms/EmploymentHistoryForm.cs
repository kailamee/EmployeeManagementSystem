﻿using System;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;
using EmployeeManagementSystem.Data;

namespace EmployeeManagementSystem.Forms
{
    public partial class EmploymentHistoryForm : Form
    {
        private readonly string _connString = ConfigurationManager.ConnectionStrings["EmployeeDb"].ConnectionString;
        private readonly string _employeeId;
        private static readonly string[] TypeOptions =
            { "Permanent", "Contractual", "Part-time", "Internship", "Temporary", "Volunteer" };

        public EmploymentHistoryForm(string employeeId, string employeeName)
        {
            InitializeComponent();

            _employeeId = employeeId;
            lblSelectedEmployee.Text = "Employee: " + employeeId + " - " + employeeName;

            this.Load += EmploymentHistoryForm_Load;
            this.chkCurrent.CheckedChanged += ChkCurrent_CheckedChanged;
            this.dgvHistory.CellClick += DgvHistory_CellClick;
        }

        // ==========================================
        // HELPER METHODS
        // ==========================================
        private static string NullIfBlank(string s) { return string.IsNullOrWhiteSpace(s) ? null : s.Trim(); }

        private static void Drain(object result)
        {
            IEnumerable rows = result as IEnumerable;
            if (rows == null) return;
            foreach (object item in rows) { }
        }

        // Fixes ugly database errors
        private static string FriendlyDbMessage(Exception ex)
        {
            SqlException sql = ex as SqlException;
            if (sql != null)
            {
                switch (sql.Number)
                {
                    case 2627:
                    case 2601:
                        return "A record with the same unique value already exists.";
                    case 547:
                        return "A data rule was violated (check the dates, employment type or the related employee).";
                    case 515:
                        return "A required field is missing.";
                }
            }
            return ex.Message;
        }

        // ==========================================
        // SETUP & LOAD
        // ==========================================
        private void EmploymentHistoryForm_Load(object sender, EventArgs e)
        {
            dgvHistory.ReadOnly = true;
            dgvHistory.AllowUserToAddRows = false;
            dgvHistory.AllowUserToDeleteRows = false;
            dgvHistory.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvHistory.MultiSelect = false;

            cmbEmploymentType.Items.Clear();
            cmbEmploymentType.Items.AddRange(TypeOptions);
            LoadHistoryGrid(); // Get the data
        }

        private void LoadHistoryGrid()
        {
            using (var db = new EmployeeManagementDataDataContext(_connString))
            {
                var history = db.usp_EmployeeHistory_ReadByEmployee(_employeeId).ToList();
                dgvHistory.DataSource = history;
            }

            if (dgvHistory.Columns.Contains("CreatedAt")) dgvHistory.Columns["CreatedAt"].Visible = false;
            if (dgvHistory.Columns.Contains("StartDate")) dgvHistory.Columns["StartDate"].DefaultCellStyle.Format = "yyyy-MM-dd";
            if (dgvHistory.Columns.Contains("EndDate")) dgvHistory.Columns["EndDate"].DefaultCellStyle.Format = "yyyy-MM-dd";
            dgvHistory.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        }

        private void ChkCurrent_CheckedChanged(object sender, EventArgs e)
        {
            dtpEndDate.Enabled = !chkCurrent.Checked;
        }

        // Safety check to make sure they filled out the required history fields
        private bool ValidateHistoryInput()
        {
            epHistory.Clear();
            bool isValid = true;

            if (string.IsNullOrWhiteSpace(txtCompanyName.Text)) { epHistory.SetError(txtCompanyName, "Company name required."); isValid = false; }
            if (string.IsNullOrWhiteSpace(txtPreviousTitle.Text)) { epHistory.SetError(txtPreviousTitle, "Job title required."); isValid = false; }
            if (cmbEmploymentType.SelectedItem == null) { epHistory.SetError(cmbEmploymentType, "Select employment type."); isValid = false; }
            if (!chkCurrent.Checked && dtpEndDate.Value.Date < dtpStartDate.Value.Date)
            {
                epHistory.SetError(dtpEndDate, "End Date cannot be earlier than Start Date.");
                isValid = false;
            }

            return isValid;
        }

        // ==========================================
        // CRUD BUTTONS
        // ==========================================

        private void btnSaveHistory_Click(object sender, EventArgs e)
        {
            if (!ValidateHistoryInput()) return;

            try
            {
                using (var db = new EmployeeManagementDataDataContext(_connString))
                {
                    DateTime? endDate = chkCurrent.Checked ? (DateTime?)null : dtpEndDate.Value.Date;

                    object result = db.usp_EmployeeHistory_Create(
                        _employeeId,
                        txtCompanyName.Text.Trim(),
                        txtPreviousTitle.Text.Trim(),
                        cmbEmploymentType.SelectedItem.ToString(),
                        dtpStartDate.Value.Date,
                        endDate,
                        NullIfBlank(txtReasonForLeaving.Text),
                        NullIfBlank(txtNotes.Text)
                    );
                    Drain(result);

                    MessageBox.Show("Employment history added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnClearHistory_Click(null, null);
                    LoadHistoryGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(FriendlyDbMessage(ex), "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdateHistory_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtHistoryId.Text))
            {
                MessageBox.Show("Select a history record to update.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ValidateHistoryInput()) return;

            try
            {
                using (var db = new EmployeeManagementDataDataContext(_connString))
                {
                    DateTime? endDate = chkCurrent.Checked ? (DateTime?)null : dtpEndDate.Value.Date;

                    object result = db.usp_EmployeeHistory_Update(
                        Convert.ToInt64(txtHistoryId.Text),
                        txtCompanyName.Text.Trim(),
                        txtPreviousTitle.Text.Trim(),
                        cmbEmploymentType.SelectedItem.ToString(),
                        dtpStartDate.Value.Date,
                        endDate,
                        NullIfBlank(txtReasonForLeaving.Text),
                        NullIfBlank(txtNotes.Text)
                    );
                    Drain(result);

                    MessageBox.Show("History record updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnClearHistory_Click(null, null);
                    LoadHistoryGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(FriendlyDbMessage(ex), "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDeleteHistory_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtHistoryId.Text))
            {
                MessageBox.Show("Select a history record to delete.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult confirm = MessageBox.Show("Are you sure you want to delete this history record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm == DialogResult.Yes)
            {
                try
                {
                    using (var db = new EmployeeManagementDataDataContext(_connString))
                    {
                        object result = db.usp_EmployeeHistory_Delete(Convert.ToInt64(txtHistoryId.Text));
                        Drain(result);

                        MessageBox.Show("Record deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        btnClearHistory_Click(null, null);
                        LoadHistoryGrid();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(FriendlyDbMessage(ex), "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Puts the data from the clicked row back into the text boxes so it can be updated
        private void DgvHistory_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || dgvHistory.CurrentRow == null) return;

            var row = dgvHistory.CurrentRow;
            epHistory.Clear();

            txtHistoryId.Text = row.Cells["HistoryId"].Value?.ToString();
            txtCompanyName.Text = row.Cells["CompanyName"].Value?.ToString();
            txtPreviousTitle.Text = row.Cells["JobTitle"].Value?.ToString();
            cmbEmploymentType.SelectedItem = row.Cells["EmploymentType"].Value?.ToString();

            DateTime startDate;
            if (DateTime.TryParse(row.Cells["StartDate"].Value?.ToString(), out startDate))
                dtpStartDate.Value = startDate;

            // Logic to check the 'Current Job' box 
            object endVal = row.Cells["EndDate"].Value;
            if (endVal == null || endVal == DBNull.Value || string.IsNullOrWhiteSpace(endVal.ToString()))
            {
                chkCurrent.Checked = true;
            }
            else
            {
                chkCurrent.Checked = false;
                DateTime endDate;
                if (DateTime.TryParse(endVal.ToString(), out endDate))
                    dtpEndDate.Value = endDate;
            }

            txtReasonForLeaving.Text = row.Cells["ReasonForLeaving"].Value?.ToString();
            txtNotes.Text = row.Cells["Notes"].Value?.ToString();
        }

        private void btnClearHistory_Click(object sender, EventArgs e)
        {
            txtHistoryId.Clear();
            txtCompanyName.Clear();
            txtPreviousTitle.Clear();
            cmbEmploymentType.SelectedIndex = -1;
            dtpStartDate.Value = DateTime.Today;
            dtpEndDate.Value = DateTime.Today;
            chkCurrent.Checked = false;
            txtReasonForLeaving.Clear();
            txtNotes.Clear();
            epHistory.Clear();
        }

        private void txtCompanyName_TextChanged(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void EmploymentHistoryForm_Load_1(object sender, EventArgs e) { }
        private void dgvHistory_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
    }
}