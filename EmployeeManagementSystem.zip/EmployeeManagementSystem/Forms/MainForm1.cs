﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using EmployeeManagementSystem.Data;

namespace EmployeeManagementSystem.Forms
{
    public partial class MainForm1 : Form
    {
        private readonly string _connString = ConfigurationManager.ConnectionStrings["EmployeeDb"].ConnectionString;

        public MainForm1()
        {
            InitializeComponent();
        }
        private void MainForm1_Load(object sender, EventArgs e)
        {
            LoadDashboardMetrics();
        }

        // Does all the math and fetches data for the home dashboard
        public void LoadDashboardMetrics()
        {
            try
            {
                using (var db = new EmployeeManagementDataDataContext(_connString))
                {
                    // Gets every employee and department from the database
                    var employees = db.vw_EmployeeDirectories.ToList();
                    var departments = db.Departments.ToList();

                    // Counts and changes the labels on the screen
                    if (Controls.Find("lblTotalEmployeesCount", true).FirstOrDefault() is Label lblTotal)
                        lblTotal.Text = employees.Count.ToString();

                    if (Controls.Find("lblActiveEmployeesCount", true).FirstOrDefault() is Label lblActive)
                        lblActive.Text = employees.Count(emp => emp.EmploymentStatus == "Active").ToString();

                    if (Controls.Find("lblTotalDepartmentsCount", true).FirstOrDefault() is Label lblDepts)
                        lblDepts.Text = departments.Count.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading dashboard metrics: " + ex.Message, "Dashboard Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnManageEmployees_Click_1(object sender, EventArgs e)
        {
            EmployeeForm empForm = new EmployeeForm();
            empForm.ShowDialog(); 
            LoadDashboardMetrics();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // ==========================================
        // DESIGNER STUBS (Empty methods so UI doesn't crash)
        // ==========================================

        // Stubs kept safely empty in case the designer is still secretly linking to them
        private void button1_Click(object sender, EventArgs e) { }
        private void btnOpenHistory_Click(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void label1_Click_1(object sender, EventArgs e) { }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
        private void btnOpenEmployees_Click(object sender, EventArgs e) { }
        private void exitToolStripMenuItem_Click(object sender, EventArgs e) { Application.Exit(); }
        private void label4_Click(object sender, EventArgs e) { }
    }
}