﻿using System;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using EmployeeManagementSystem.Data;

namespace EmployeeManagementSystem.Forms
{
    public partial class EmployeeForm : Form
    {
        private readonly string _connString = ConfigurationManager.ConnectionStrings["EmployeeDb"].ConnectionString;
        private static readonly string[] SexOptions = { "Male", "Female", "Prefer not to say" };
        private static readonly string[] StatusOptions = { "Active", "On Leave", "Resigned", "Terminated", "Retired" };

        public EmployeeForm()
        {
            InitializeComponent();
            this.Load += EmployeeForm_Load;
            this.dtpBirthDate.ValueChanged += DtpBirthDate_ValueChanged;
            this.dgvEmployees.CellClick += DgvEmployees_CellClick;
        }

        private static string NullIfBlank(string s) { return string.IsNullOrWhiteSpace(s) ? null : s.Trim(); }

        private static void Drain(object result)
        {
            IEnumerable rows = result as IEnumerable;
            if (rows == null) return;
            foreach (object item in rows) { }
        }

        private static string FriendlyDbMessage(Exception ex)
        {
            SqlException sql = ex as SqlException;
            if (sql != null)
            {
                switch (sql.Number)
                {
                    case 2627:
                    case 2601:
                        return "An employee with this exact Full Name or Email address already exists in the system.";
                    case 547:
                        return "A data rule was violated (check dates, salary, status, department or related records).";
                    case 515:
                        return "A required field is missing.";
                }
            }
            return ex.Message;
        }

        private void EmployeeForm_Load(object sender, EventArgs e)
        {
            ConfigureGrid();
            LoadDepartments();
            LoadStatusDropdowns();
            RefreshEmployeeGrid();
        }

        private void ConfigureGrid()
        {
            dgvEmployees.ReadOnly = true;
            dgvEmployees.AllowUserToAddRows = false;
            dgvEmployees.AllowUserToDeleteRows = false;
            dgvEmployees.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvEmployees.MultiSelect = false;
        }

        private void LoadDepartments()
        {
            using (var db = new EmployeeManagementDataDataContext(_connString))
            {
                var depts = db.Departments.Select(d => new { d.DepartmentId, d.DepartmentName }).ToList();

                // Main add/update 
                cmbDepartment.DataSource = depts;
                cmbDepartment.DisplayMember = "DepartmentName";
                cmbDepartment.ValueMember = "DepartmentId";
                cmbDepartment.SelectedIndex = -1;

                // Search Dropdown
                var filterDepts = depts.ToList();
                filterDepts.Insert(0, new { DepartmentId = 0, DepartmentName = "--- All Departments ---" });
                cmbFilterDepartment.DataSource = filterDepts;
                cmbFilterDepartment.DisplayMember = "DepartmentName";
                cmbFilterDepartment.ValueMember = "DepartmentId";
                cmbFilterDepartment.SelectedIndex = 0;
            }
        }

        private void LoadStatusDropdowns()
        {
            cmbSex.Items.Clear();
            cmbSex.Items.AddRange(SexOptions);
            cmbStatus.Items.Clear();
            cmbStatus.Items.AddRange(StatusOptions);
            cmbStatus.SelectedItem = "Active";

            cmbFilterStatus.Items.Clear();
            cmbFilterStatus.Items.Add("--- All Statuses ---");
            cmbFilterStatus.Items.AddRange(StatusOptions);
            cmbFilterStatus.SelectedIndex = 0;
        }

        private void RefreshEmployeeGrid(string search = null, int? deptId = null, string status = null)
        {
            using (var db = new EmployeeManagementDataDataContext(_connString))
            {
                int? actualDeptId = (deptId.HasValue && deptId.Value > 0) ? deptId : null;
                string actualStatus = (!string.IsNullOrEmpty(status) && !status.StartsWith("---")) ? status : null;
                var results = db.usp_Employee_Search(NullIfBlank(search), actualDeptId, actualStatus).ToList();
                dgvEmployees.DataSource = results;
            }
            TidyGridColumns();
        }

        private void TidyGridColumns()
        {
            foreach (string col in new[] { "FullName", "DepartmentId", "CreatedAt", "UpdatedAt" })
            {
                if (dgvEmployees.Columns.Contains(col)) dgvEmployees.Columns[col].Visible = false;
            }
            if (dgvEmployees.Columns.Contains("BirthDate")) dgvEmployees.Columns["BirthDate"].DefaultCellStyle.Format = "yyyy-MM-dd";
            if (dgvEmployees.Columns.Contains("HireDate")) dgvEmployees.Columns["HireDate"].DefaultCellStyle.Format = "yyyy-MM-dd";
            if (dgvEmployees.Columns.Contains("Salary")) dgvEmployees.Columns["Salary"].DefaultCellStyle.Format = "₱#,##0.00";

            dgvEmployees.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
        }

        private void DtpBirthDate_ValueChanged(object sender, EventArgs e)
        {
            int age = DateTime.Today.Year - dtpBirthDate.Value.Year;
            if (dtpBirthDate.Value.Date > DateTime.Today.AddYears(-age)) age--;
            lblAge.Text = age >= 0 ? age.ToString() : "0";
        }

        // ==========================================
        // VALIDATION & CRUD OPERATIONS (Buttons)
        // ==========================================

        private bool ValidateInput()
        {
            epInput.Clear();
            bool isValid = true;

            // Name & Status Checks
            if (string.IsNullOrWhiteSpace(txtFirstName.Text)) { epInput.SetError(txtFirstName, "First name is required."); isValid = false; }
            if (string.IsNullOrWhiteSpace(txtLastName.Text)) { epInput.SetError(txtLastName, "Last name is required."); isValid = false; }
            if (cmbSex.SelectedItem == null) { epInput.SetError(cmbSex, "Select sex."); isValid = false; }
            if (cmbDepartment.SelectedItem == null) { epInput.SetError(cmbDepartment, "Select department."); isValid = false; }
            if (string.IsNullOrWhiteSpace(txtJobTitle.Text)) { epInput.SetError(txtJobTitle, "Job title is required."); isValid = false; }
            if (cmbStatus.SelectedItem == null) { epInput.SetError(cmbStatus, "Select employment status."); isValid = false; }

            // NEW: Phone and Address are now required
            if (string.IsNullOrWhiteSpace(txtPhone.Text)) { epInput.SetError(txtPhone, "Phone number is required."); isValid = false; }
            if (string.IsNullOrWhiteSpace(txtAddress.Text)) { epInput.SetError(txtAddress, "Address is required."); isValid = false; }

            // Date Checks
            if (dtpBirthDate.Value.Date >= DateTime.Today)
            {
                epInput.SetError(dtpBirthDate, "Birth date must be in the past.");
                isValid = false;
            }

            if (string.IsNullOrWhiteSpace(txtEmail.Text) || !Regex.IsMatch(txtEmail.Text.Trim(), @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                epInput.SetError(txtEmail, "Valid email is required.");
                isValid = false;
            }

            // NEW: Employee must be at least 18 years old on their hire date
            if (dtpHireDate.Value.Date < dtpBirthDate.Value.Date.AddYears(18))
            {
                epInput.SetError(dtpHireDate, "Employee must be at least 18 years old on their hire date.");
                isValid = false;
            }

            // Salary Check
            if (nudSalary.Value < 0)
            {
                epInput.SetError(nudSalary, "Salary must be 0 or greater.");
                isValid = false;
            }

            return isValid;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            string firstName = txtFirstName.Text.Trim();
            string lastName = txtLastName.Text.Trim();

            // Forces middle name to be exactly NULL if it is left blank
            string middleName = NullIfBlank(txtMiddleName.Text);

            try
            {
                using (var db = new EmployeeManagementDataDataContext(_connString))
                {
                    // NEW: Duplicate check now looks at First, Last, AND Middle Name.
                    bool duplicateExists = db.vw_EmployeeDirectories.Any(emp =>
                        emp.FirstName == firstName &&
                        emp.LastName == lastName &&
                        emp.MiddleName == middleName);

                    if (duplicateExists)
                    {
                        MessageBox.Show($"An employee named '{firstName} {middleName} {lastName}' already exists.", "Duplicate Prevented", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    string generatedId = null;

                    object result = db.usp_Employee_Create(
                        firstName, middleName, lastName, cmbSex.SelectedItem.ToString(),
                        dtpBirthDate.Value.Date, txtEmail.Text.Trim(), txtPhone.Text.Trim(), txtAddress.Text.Trim(),
                        Convert.ToInt32(cmbDepartment.SelectedValue), txtJobTitle.Text.Trim(), cmbStatus.SelectedItem.ToString(),
                        dtpHireDate.Value.Date, nudSalary.Value, ref generatedId);

                    Drain(result);
                    MessageBox.Show("Employee created! ID: " + generatedId, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnClear_Click(null, null);
                    RefreshEmployeeGrid();
                }
            }
            catch (Exception ex) { MessageBox.Show(FriendlyDbMessage(ex), "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtEmployeeId.Text)) { MessageBox.Show("Select an employee.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (!ValidateInput()) return;

            string firstName = txtFirstName.Text.Trim();
            string lastName = txtLastName.Text.Trim();
            string middleName = NullIfBlank(txtMiddleName.Text);

            try
            {
                using (var db = new EmployeeManagementDataDataContext(_connString))
                {
                    // NEW: Ensure we aren't changing this employee's name to perfectly match an existing employee
                    bool duplicateExists = db.vw_EmployeeDirectories.Any(emp =>
                        emp.EmployeeId != txtEmployeeId.Text &&
                        emp.FirstName == firstName &&
                        emp.LastName == lastName &&
                        emp.MiddleName == middleName);

                    if (duplicateExists)
                    {
                        MessageBox.Show($"Another employee named '{firstName} {middleName} {lastName}' already exists.", "Duplicate Prevented", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    object result = db.usp_Employee_Update(
                        txtEmployeeId.Text, firstName, middleName, lastName,
                        cmbSex.SelectedItem.ToString(), dtpBirthDate.Value.Date, txtEmail.Text.Trim(), txtPhone.Text.Trim(),
                        txtAddress.Text.Trim(), Convert.ToInt32(cmbDepartment.SelectedValue), txtJobTitle.Text.Trim(),
                        cmbStatus.SelectedItem.ToString(), dtpHireDate.Value.Date, nudSalary.Value);

                    Drain(result);
                    MessageBox.Show("Employee updated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnClear_Click(null, null);
                    RefreshEmployeeGrid();
                }
            }
            catch (Exception ex) { MessageBox.Show(FriendlyDbMessage(ex), "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtEmployeeId.Text)) { MessageBox.Show("Select an employee.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

            if (MessageBox.Show("Delete " + txtEmployeeId.Text + "?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    using (var db = new EmployeeManagementDataDataContext(_connString))
                    {
                        Drain(db.usp_Employee_Delete(txtEmployeeId.Text));
                        MessageBox.Show("Employee deleted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        btnClear_Click(null, null);
                        RefreshEmployeeGrid();
                    }
                }
                catch (Exception ex) { MessageBox.Show(FriendlyDbMessage(ex), "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }

        private void DgvEmployees_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || dgvEmployees.CurrentRow == null) return;
            var row = dgvEmployees.CurrentRow;
            epInput.Clear();

            txtEmployeeId.Text = row.Cells["EmployeeId"].Value?.ToString();
            txtFirstName.Text = row.Cells["FirstName"].Value?.ToString();
            txtMiddleName.Text = row.Cells["MiddleName"].Value?.ToString();
            txtLastName.Text = row.Cells["LastName"].Value?.ToString();
            cmbSex.SelectedItem = row.Cells["Sex"].Value?.ToString();

            if (DateTime.TryParse(row.Cells["BirthDate"].Value?.ToString(), out DateTime bday)) dtpBirthDate.Value = bday;
            lblAge.Text = row.Cells["Age"].Value?.ToString();
            txtEmail.Text = row.Cells["Email"].Value?.ToString();
            txtPhone.Text = row.Cells["Phone"].Value?.ToString();
            txtAddress.Text = row.Cells["Address"].Value?.ToString();

            object dep = row.Cells["DepartmentId"].Value;
            if (dep != null && dep != DBNull.Value) cmbDepartment.SelectedValue = Convert.ToInt32(dep);
            else cmbDepartment.SelectedIndex = -1;

            txtJobTitle.Text = row.Cells["JobTitle"].Value?.ToString();
            cmbStatus.SelectedItem = row.Cells["EmploymentStatus"].Value?.ToString();

            if (DateTime.TryParse(row.Cells["HireDate"].Value?.ToString(), out DateTime hireDate)) dtpHireDate.Value = hireDate;
            if (decimal.TryParse(row.Cells["Salary"].Value?.ToString(), out decimal salary))
                nudSalary.Value = Math.Max(nudSalary.Minimum, Math.Min(nudSalary.Maximum, salary));
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtEmployeeId.Clear(); txtFirstName.Clear(); txtMiddleName.Clear(); txtLastName.Clear();
            cmbSex.SelectedIndex = -1; dtpBirthDate.Value = DateTime.Today; lblAge.Text = "0";
            txtEmail.Clear(); txtPhone.Clear(); txtAddress.Clear(); cmbDepartment.SelectedIndex = -1;
            txtJobTitle.Clear(); cmbStatus.SelectedItem = "Active"; dtpHireDate.Value = DateTime.Today; nudSalary.Value = 0;
            epInput.Clear();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            RefreshEmployeeGrid(txtSearch.Text, Convert.ToInt32(cmbFilterDepartment.SelectedValue), cmbFilterStatus.SelectedItem?.ToString());
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtEmployeeId.Text)) { MessageBox.Show("Select an employee first."); return; }
            new EmploymentHistoryForm(txtEmployeeId.Text, txtFirstName.Text + " " + txtLastName.Text).ShowDialog();
        }

        private void txtFirstName_TextChanged(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void cmbSex_SelectedIndexChanged(object sender, EventArgs e) { }
        private void lblAge_Click(object sender, EventArgs e) { }
        private void label9_Click(object sender, EventArgs e) { }
        private void label16_Click(object sender, EventArgs e) { }
        private void btnSave_Click_1(object sender, EventArgs e) { btnSave_Click(sender, e); }
        private void cmbFilterDepartment_SelectedIndexChanged(object sender, EventArgs e) { }
        private void EmployeeForm_Load_1(object sender, EventArgs e) { }
    }
}